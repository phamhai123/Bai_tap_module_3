/* URL: https://www.microsoft.com/en-us/store/b/surface */
/* Extended Data: geo = us, mc1 = 7b9fec5f43454e2f814d1a2b1b80cac9 */
/* Actions Fired:
* Id = 11087209860887, Name = Any category page
* Id = 11087215742809, Name = Global Category Pageview
*/
/* Third-Party Tags Fired:
None
*/
!function(){function e(e){function t(e){for(var a=e.childNodes,o=0;o<a.length;o++)t(a[o]);if(e.tagName===n){var c=document.createElement(n);e.getAttribute(r)&&c.setAttribute(r,e.getAttribute(r)),c.text=e.text,e.parentNode.insertBefore(c,e),e.parentNode.removeChild(e)}}var n="SCRIPT",r="src",a=document.createDocumentFragment(),o=document.createElement("I");a.appendChild(o),o.innerHTML='<em style="display:none;">&nbsp;</em>'+e,t(o);var c=document.getElementsByTagName("script")[0];c.parentNode.insertBefore(a,c)}var t="";if(t){var n=document.write;document.write=function(t){try{n(t)}catch(r){e(t)}},e(t)}}();